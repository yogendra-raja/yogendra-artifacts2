
from pathlib import Path
import sys

test_dir = Path(__file__).parent
BASE_DIR = 'agent_ready_tools'
MAX_DEPTH = 10

while test_dir.name != BASE_DIR:
    test_dir = test_dir.parent
    MAX_DEPTH -= 1
    if MAX_DEPTH == 0:
        raise RecursionError(f"'{BASE_DIR}' not found in path: {__file__}")
parent_path = test_dir.parent.resolve()

sys.path.append(str(parent_path))    
    
from typing import ClassVar, Type

from ibm_watsonx_orchestrate.agent_builder.tools import tool
from marshmallow import Schema
from marshmallow_dataclass import dataclass

from agent_ready_tools.clients.box_client import get_box_client
from agent_ready_tools.utils.tool_connections import BOX_CONNECTIONS


@dataclass
class AddACommentResult:
    """Represents the result of add a comment in Box."""

    comment_id: str
    comment: str

    Schema: ClassVar[Type[Schema]]


@tool(expected_credentials=BOX_CONNECTIONS.as_json_list)
def add_a_comment(
    file_id: str,
    comment: str,
) -> AddACommentResult:
    """
    Adds a comment for a Box file.

    :param file_id: The id for the file returned by `get_file_details_by_name` tool.
    :param comment: The comment message for the file.
    :return: The result from performing the add a comment.
    """
    client = get_box_client()

    payload = {"item": {"id": file_id, "type": "file"}, "message": comment}
    response = client.post_request(entity="comments", data=payload)

    return AddACommentResult(comment_id=response.get("id", ""), comment=response.get("message", ""))
