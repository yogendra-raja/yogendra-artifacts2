from enum import StrEnum
from typing import ClassVar, Dict, List, Optional, Type

from ibm_watsonx_orchestrate.client.connections import ConnectionType
from marshmallow import Schema
from marshmallow_dataclass import dataclass

from agent_ready_tools.clients.clients_enums import AccessLevel, AribaApplications, DNBEntitlements
from agent_ready_tools.utils.systems import Systems


@dataclass
class Connection:
    """Defines a connection app-id and type required by a tool."""

    app_id: str
    type: ConnectionType

    Schema: ClassVar[Type[Schema]] = Schema

    def __post_init__(self):
        if self.type not in ConnectionType:
            raise ValueError(
                f"Invalid type '{self.type}' for connection with app-id: '{self.app_id}'"
            )

    @property
    def as_json(self) -> Dict:
        """Returns a dict of keys and values."""
        return self.__dict__


@dataclass
class Connections:
    """Defines a list of connections required by a tool."""

    connections_list: List[Connection]

    Schema: ClassVar[Type[Schema]] = Schema

    @property
    def as_json_list(self) -> List[Dict]:
        """Returns a list of ExpectedConnected dicts."""
        return [c.as_json for c in self.connections_list]


class InvalidConnectionSubCategoryError(ValueError):
    """Exception raised when a given system sub_category is invalid."""

    def __init__(
        self, system: Systems, sub_category: Optional[str], sub_category_enum: Type[StrEnum]
    ):
        """Initialize as ValueError with specific str."""
        super().__init__(
            f"Invalid sub_category for {system} connections: {sub_category}. Must be one of: {list(sub_category_enum)}"
        )


class UnsupportedConnectionSubCategoryError(ValueError):
    """Exception raised when a given (valid) system sub_category has no defined connections."""

    def __init__(self, system: Systems, sub_category: Optional[str]):
        """Initialize as ValueError with specific str."""
        super().__init__(f"Unsupported sub_category for {system} connections: {sub_category}")


### Connection Constants

ARIBA_BASE_CONNECTION = Connection(app_id="ariba_base_key_value", type=ConnectionType.KEY_VALUE)

ARIBA_BUYER_CONNECTIONS = Connections(
    connections_list=[
        ARIBA_BASE_CONNECTION,
        Connection(app_id="ariba_buyer_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

ARIBA_SUPPLIER_CONNECTIONS = Connections(
    connections_list=[
        ARIBA_BASE_CONNECTION,
        Connection(app_id="ariba_supplier_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

BOX_CONNECTIONS = Connections(
    connections_list=[
        Connection(app_id="box_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

COUPA_CONNECTIONS = Connections(
    connections_list=[
        Connection(app_id="coupa_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

DNB_BASE_CONNECTION = Connection(app_id="dnb_base_key_value", type=ConnectionType.KEY_VALUE)

DNB_PROCUREMENT_CONNECTIONS = Connections(
    connections_list=[
        DNB_BASE_CONNECTION,
        Connection(app_id="dnb_procurement_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

DNB_SALES_CONNECTIONS = Connections(
    connections_list=[
        DNB_BASE_CONNECTION,
        Connection(app_id="dnb_sales_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

GOOGLE_CONNECTIONS = Connections(
    connections_list=[
        Connection(app_id="google_key_value", type=ConnectionType.KEY_VALUE),
    ]
)
ADOBE_WORKFRONT_CONNECTIONS = Connections(
    connections_list=[
        Connection(app_id="adobe_workfront_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

JIRA_CONNECTIONS = Connections(
    connections_list=[
        Connection(app_id="jira_basic", type=ConnectionType.BASIC_AUTH),
        Connection(app_id="jira_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

MICROSOFT_CONNECTIONS = Connections(
    connections_list=[
        Connection(app_id="microsoft_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

ORACLE_HCM_CONNECTIONS = Connections(
    connections_list=[
        Connection(app_id="oracle_hcm_basic", type=ConnectionType.BASIC_AUTH),
        Connection(app_id="oracle_hcm_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

SALESFORCE_CONNECTIONS = Connections(
    connections_list=[
        Connection(app_id="salesforce_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

SAP_SUCCESSFACTORS_CONNECTIONS = Connections(
    connections_list=[
        Connection(app_id="sap_successfactors_basic", type=ConnectionType.BASIC_AUTH),
        Connection(app_id="sap_successfactors_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

SLACK_CONNECTIONS = Connections(
    connections_list=[
        Connection(app_id="slack_bearer", type=ConnectionType.BEARER_TOKEN),
        Connection(app_id="slack_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

WORKDAY_BASE_CONNECTION = Connection(app_id="workday_base_key_value", type=ConnectionType.KEY_VALUE)

WORKDAY_EMPLOYEE_CONNECTIONS = Connections(
    connections_list=[
        WORKDAY_BASE_CONNECTION,
        Connection(app_id="workday_employee_key_value", type=ConnectionType.KEY_VALUE),
    ]
)


WORKDAY_MANAGER_CONNECTIONS = Connections(
    connections_list=[
        WORKDAY_BASE_CONNECTION,
        Connection(app_id="workday_manager_key_value", type=ConnectionType.KEY_VALUE),
    ]
)

SAP_S4_HANA_CONNECTIONS = Connections(
    connections_list=[
        Connection(app_id="sap_s4_hana_basic", type=ConnectionType.BASIC_AUTH),
        Connection(app_id="sap_s4_hana_key_value", type=ConnectionType.KEY_VALUE),
    ]
)


def get_system_connections(
    system: Systems, sub_category: Optional[str] = None
) -> Optional[Connections]:
    """
    Returns the required connection configration for a given system's tools.

    :param system: The system to return connections for.
    :param sub_category: A specific sub-category of creds for the given system.
    :return: The connections for the system.
    """
    if system == Systems.SAP_SUCCESSFACTORS:
        return SAP_SUCCESSFACTORS_CONNECTIONS
    elif system == Systems.ORACLE_HCM:
        return ORACLE_HCM_CONNECTIONS
    elif system == Systems.BOX:
        return BOX_CONNECTIONS
    elif system == Systems.SALESFORCE:
        return SALESFORCE_CONNECTIONS
    elif system == Systems.COUPA:
        return COUPA_CONNECTIONS
    elif system == Systems.GOOGLE:
        return GOOGLE_CONNECTIONS
    elif system == Systems.JIRA:
        return JIRA_CONNECTIONS
    elif system == Systems.MICROSOFT:
        return MICROSOFT_CONNECTIONS
    elif system == Systems.SLACK:
        return SLACK_CONNECTIONS
    elif system == Systems.SAP_S4_HANA:
        return SAP_S4_HANA_CONNECTIONS
    elif system == Systems.ARIBA:
        if sub_category not in AribaApplications:
            raise InvalidConnectionSubCategoryError(system, sub_category, AribaApplications)
        elif sub_category == AribaApplications.BUYER:
            return ARIBA_BUYER_CONNECTIONS
        elif sub_category == AribaApplications.SUPPLIER:
            return ARIBA_SUPPLIER_CONNECTIONS
        raise UnsupportedConnectionSubCategoryError(system, sub_category)
    elif system == Systems.DNB:
        if sub_category not in DNBEntitlements:
            raise InvalidConnectionSubCategoryError(system, sub_category, DNBEntitlements)
        elif sub_category == DNBEntitlements.PROCUREMENT:
            return DNB_PROCUREMENT_CONNECTIONS
        elif sub_category == DNBEntitlements.SALES:
            return DNB_SALES_CONNECTIONS
        raise UnsupportedConnectionSubCategoryError(system, sub_category)
    elif system == Systems.WORKDAY:
        if sub_category not in AccessLevel:
            raise InvalidConnectionSubCategoryError(system, sub_category, AccessLevel)
        elif sub_category == AccessLevel.EMPLOYEE:
            return WORKDAY_EMPLOYEE_CONNECTIONS
        elif sub_category == AccessLevel.MANAGER:
            return WORKDAY_MANAGER_CONNECTIONS
        raise UnsupportedConnectionSubCategoryError(system, sub_category)
    return None
