"""
NOTE: The structure and contents of this file are tied to the import script for importing tools.
Please ensure tools can properly be imported and authenticated into the SDK server after making changes.
"""

from enum import StrEnum
import json
import os
from pathlib import Path
from typing import Dict, Optional

from ibm_watsonx_orchestrate.client.connections import ConnectionType
from ibm_watsonx_orchestrate.run import connections

from agent_ready_tools.utils.systems import Systems
from agent_ready_tools.utils.tool_connections import get_system_connections
from agent_ready_tools.utils.tool_credentials import get_expected_credentials

PANTS_SANDBOX_SUBSTR = "pants-sandbox"


class CredentialKeys(StrEnum):
    """Types of credential keys for different systems."""

    API_KEY = "api_key"
    AUTHORITY = "authority"
    BASE_URL = "base_url"
    BEARER_TOKEN = "bearer_token"
    CLIENT_ID = "client_id"
    CLIENT_SECRET = "client_secret"
    DOMAIN = "domain"
    PASSWORD = "password"
    REALM = "realm"
    REFRESH_TOKEN = "refresh_token"
    SUBJECT_ID = "subject_id"
    SUBJECT_TYPE = "subject_type"
    TENANT_NAME = "tenant_name"
    TOKEN_URL = "token_url"
    USER_ID = "user_id"
    USERNAME = "username"
    BUYER_ANID = "buyer_anid"


def _in_pants_sandbox() -> bool:
    """Are we currently in a pants sandbox?"""
    return PANTS_SANDBOX_SUBSTR in os.getcwd()


def _merge_base_and_subcategory(system_creds: Dict, sub_category: Optional[str] = None) -> Dict:
    """
    Returns the base credential values and any values for the specified sub_category.

    :param system_creds: The complete set of credentials for a given system.
    :param sub_category: The sub-category of creds desired.
    :return: Dict of merged creds.
    """
    if sub_category:
        return {k: v for k, v in system_creds.items() if isinstance(v, str)} | system_creds[
            sub_category
        ]
    else:
        return system_creds


def get_tool_credentials(
    system: Systems,
    sub_category: Optional[str] = None,
) -> Dict:
    """
    Gets tools credentials from SDK server or credentials.json.

    :param system: The system for which to return creds.
    :param sub_category: A specific sub-category of creds for the given system.
    :return: Dict of creds.
    """
    if system in [Systems.WORKDAY, Systems.ARIBA, Systems.DNB]:
        assert sub_category, f"System {system} must specify a sub-category to obtain credentials."

    # local integration test, return from credentials.json
    if _in_pants_sandbox():
        creds_path = Path(__file__).parent / "credentials.json"
        with open(creds_path) as creds:
            system_creds: Dict = json.load(creds).get(system, {})
            return _merge_base_and_subcategory(system_creds, sub_category)

    # in SDK env
    required_connections = get_expected_credentials(system, sub_category)

    if required_connections is None:
        sys_conns = get_system_connections(system, sub_category)
        if sys_conns:
            required_connections = sys_conns.connections_list

    if required_connections:
        merged_conn_creds: Dict = {}
        for connection in required_connections:
            if connection.type == ConnectionType.BASIC_AUTH:
                conn = connections.basic_auth(connection.app_id)
                merged_conn_creds[CredentialKeys.USERNAME] = conn.username
                merged_conn_creds[CredentialKeys.PASSWORD] = conn.password
            elif connection.type == ConnectionType.BEARER_TOKEN:
                conn = connections.bearer_token(connection.app_id)
                merged_conn_creds[CredentialKeys.BEARER_TOKEN] = conn.token
            elif connection.type == ConnectionType.KEY_VALUE:
                conn = connections.key_value(connection.app_id)
                for key in conn:
                    merged_conn_creds[key] = conn[key]
            else:
                raise ValueError(
                    f"ConnectionType {connection.type} for app-id {connection.app_id} is not supported."
                )
        return merged_conn_creds
    else:
        # see 'create_flattened_module()' in flat_tools.py
        # TODO: remove once all APIs have 'connections' in SDK server
        all_creds: Dict = {"TODO": {}}
        system_creds = all_creds.get(system, {})
        return _merge_base_and_subcategory(system_creds, sub_category)
