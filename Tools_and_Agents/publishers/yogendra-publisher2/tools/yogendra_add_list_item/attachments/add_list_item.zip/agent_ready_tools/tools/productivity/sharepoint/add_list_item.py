
from pathlib import Path
import sys

test_dir = Path(__file__).parent
BASE_DIR = 'agent_ready_tools'
MAX_DEPTH = 10

while test_dir.name != BASE_DIR:
    test_dir = test_dir.parent
    MAX_DEPTH -= 1
    if MAX_DEPTH == 0:
        raise RecursionError(f"'{BASE_DIR}' not found in path: {__file__}")
parent_path = test_dir.parent.resolve()

sys.path.append(str(parent_path))    
    
from typing import ClassVar, Type

from ibm_watsonx_orchestrate.agent_builder.tools import tool
from marshmallow import Schema
from marshmallow_dataclass import dataclass

from agent_ready_tools.clients.microsoft_client import get_microsoft_client
from agent_ready_tools.utils.tool_connections import MICROSOFT_CONNECTIONS


@dataclass
class AddListItemResponse:
    """Represents the result of adding an item to a list in Microsoft Sharepoint."""

    title: str

    Schema: ClassVar[Type[Schema]]


@tool(expected_credentials=MICROSOFT_CONNECTIONS.as_json_list)
def add_list_item(site_id: str, list_id: str, title: str) -> AddListItemResponse:
    """
    Adds a new item to a list in Microsoft Sharepoint.

    :param title: The title of the list item.
    :param site_id: The site_id uniquely identifying them within the MS Graph API, returned by `get_sites` tool.
    :param list_id: The list_id uniquely identifying them within the MS Graph API, returned by `get_lists` tool.

    :return: The title of the created list item.
    """
    client = get_microsoft_client()

    payload = {"fields": {"Title": title}}

    response = client.post_request(endpoint=f"sites/{site_id}/lists/{list_id}/items", data=payload)

    return AddListItemResponse(title=response.get("fields", "").get("Title", ""))
