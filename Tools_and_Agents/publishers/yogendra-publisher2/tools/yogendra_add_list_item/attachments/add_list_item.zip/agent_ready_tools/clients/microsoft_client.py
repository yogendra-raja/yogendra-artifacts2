from typing import Any, Dict, Optional

import msal
import requests

from agent_ready_tools.utils.credentials import CredentialKeys, get_tool_credentials
from agent_ready_tools.utils.systems import Systems


class MicrosoftClient:
    """A remote client for Microsoft Graph API."""

    VERSION_1 = "v1.0"

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        username: str,
        password: str,
        authority: str,
        base_url: str,
    ):
        """
        :param client_id: The Microsoft Entra Application (client) ID.
        :param client_secret: The Microsoft Entra client secret.
        :param username: The Microsoft account username (email address).
        :param password: The Microsoft account password.
        :param authority: The Microsoft Entra authority URL.
        :param base_url: The Microsoft Graph API URL.
        """

        self.base_url = base_url
        self.token_cache = msal.TokenCache()

        self.__username = username
        self.__password = password
        self.__scopes: list[str] = []

        self.msal_client_app = msal.ConfidentialClientApplication(
            client_id,
            authority=authority,
            client_credential=client_secret,
            token_cache=self.token_cache,
        )

        self.token = self.__get_access_token()

    def get_request(
        self,
        endpoint: str,
        version: str = VERSION_1,
        params: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """
        Executes a GET request against a Microsoft Graph API.

        :param endpoint: The specific endpoint to make the request against.
        :param version: The specific version of the API, usually but not limited to "v1.0"
        :param params: Query parameters for the request.
        :return: The JSON response from the request.
        """

        self.token = self.__get_access_token()

        headers = {"Authorization": f"Bearer {self.token}"}

        response = requests.get(
            url=f"{self.base_url}/{version}/{endpoint}",
            headers=headers,
            params=params,
        )

        response.raise_for_status()
        result = response.json()
        result["status_code"] = response.status_code
        return result

    def post_request(
        self,
        endpoint: str,
        data: dict,
        version: str = VERSION_1,
        headers: Optional[Dict[str, str]] = None,
    ) -> dict[str, Any]:
        """
        Executes a POST request against a Microsoft Graph API.

        :param endpoint: The specific endpoint to make the request against.
        :param data: The Input data request.
        :param version: The specific version of the API, usually but not limited to "v1.0"
        :param headers: The headers value for the request.
        :return: The JSON response from the request.
        """

        self.token = self.__get_access_token()

        if headers is None:
            headers = {"Authorization": f"Bearer {self.token}"}
        else:
            headers["Authorization"] = f"Bearer {self.token}"

        response = requests.post(
            url=f"{self.base_url}/{version}/{endpoint}",
            headers=headers,
            json=data,
        )
        response.raise_for_status()
        result = {}
        if response.content:
            result = response.json()
        else:
            result["status_code"] = response.status_code
        return result

    def update_request(self, endpoint: str, data: dict, version: str = VERSION_1) -> dict[str, Any]:
        """
        Executes an update (PATCH) request against the Microsoft Graph API.

        :param endpoint: The specific endpoint to make the request against. The endpoint should contain the entity ID to be updated.
        :param data: A dictionary containing the input payload.
        :param version: The specific version of the API, usually but not limited to "v1.0"
        :return: The JSON response from the request.
        """

        self.token = self.__get_access_token()

        headers = {"Authorization": f"Bearer {self.token}"}

        response = requests.patch(
            url=f"{self.base_url}/{version}/{endpoint}",
            headers=headers,
            json=data,
        )

        response.raise_for_status()
        result = {}
        if response.content:
            result = response.json()
        else:
            result["status_code"] = response.status_code
        return result

    def delete_request(self, endpoint: str, version: str = VERSION_1) -> int:
        """
        Executes a DELETE request against the Microsoft Graph API.

        :param endpoint: The specific endpoint to make the request against. The endpoint should contain the entity ID to be deleted.
        :param version: The specific version of the API, usually but not limited to "v1.0"
        :return: The status code of the request.
        """

        self.token = self.__get_access_token()

        headers = {"Authorization": f"Bearer {self.token}"}

        response = requests.delete(url=f"{self.base_url}/{version}/{endpoint}", headers=headers)

        response.raise_for_status()
        return response.status_code

    def __get_access_token(self) -> str:
        """
        :return: An access token.
        """

        result = None

        accounts = self.msal_client_app.get_accounts(username=self.__username)

        if accounts:
            result = self.msal_client_app.acquire_token_silent(self.__scopes, account=accounts[0])

        if not result:
            result = self.msal_client_app.acquire_token_by_username_password(
                self.__username, self.__password, scopes=self.__scopes
            )

        if "access_token" in result:
            return result["access_token"]
        else:
            return ""


def get_microsoft_client() -> MicrosoftClient:
    """
    Get the microsoft client with credentials.

    NOTE: DO NOT CALL DIRECTLY IN TESTING!

    To test, either mock this call or call the client directly.

    :return: A new instance of the Microsoft client.
    """
    credentials = get_tool_credentials(Systems.MICROSOFT)
    microsoft_client = MicrosoftClient(
        client_id=credentials[CredentialKeys.CLIENT_ID],
        client_secret=credentials[CredentialKeys.CLIENT_SECRET],
        username=credentials[CredentialKeys.USERNAME],
        password=credentials[CredentialKeys.PASSWORD],
        authority=credentials[CredentialKeys.AUTHORITY],
        base_url=credentials[CredentialKeys.BASE_URL],
    )
    return microsoft_client
