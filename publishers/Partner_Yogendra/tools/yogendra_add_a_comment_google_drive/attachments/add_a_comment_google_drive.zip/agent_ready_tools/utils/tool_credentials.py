from typing import Optional

from ibm_watsonx_orchestrate.agent_builder.connections.types import (
    ConnectionType,
    ExpectedCredentials,
)

from agent_ready_tools.utils.systems import Systems

### Connection Constants
MILVUS_CIO_CONNECTIONS = [
    ExpectedCredentials(app_id="milvus_cio_key_value", type=ConnectionType.KEY_VALUE),
]

SEISMIC_CONNECTIONS = [
    ExpectedCredentials(app_id="seismic_key_value", type=ConnectionType.KEY_VALUE),
]

SERVICENOW_CONNECTIONS = [
    ExpectedCredentials(app_id="servicenow_bearer", type=ConnectionType.BEARER_TOKEN),
    ExpectedCredentials(app_id="servicenow_key_value", type=ConnectionType.KEY_VALUE),
]


WATSONX_AI_CONNECTIONS = [
    ExpectedCredentials(app_id="watsonx_ai_key_value", type=ConnectionType.KEY_VALUE),
]


def get_expected_credentials(
    system: Systems, sub_category: Optional[str] = None
) -> Optional[ExpectedCredentials]:
    """
    Returns the required ExpectedCredentials configuration for a given system's tools.

    :param system: The system to return connections for.
    :param sub_category: A specific sub-category of creds for the given system.
    :return: The ExpectedCredentials for the system.
    """
    if sub_category:
        return None

    if system == Systems.MILVUS:
        return MILVUS_CIO_CONNECTIONS
    elif system == Systems.SEISMIC:
        return SEISMIC_CONNECTIONS
    elif system == Systems.SERVICENOW:
        return SERVICENOW_CONNECTIONS
    elif system == Systems.WATSONX_AI:
        return WATSONX_AI_CONNECTIONS
    return None
