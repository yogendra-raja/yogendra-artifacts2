
from pathlib import Path
import sys

test_dir = Path(__file__).parent
BASE_DIR = 'agent_ready_tools'
MAX_DEPTH = 10

while test_dir.name != BASE_DIR:
    test_dir = test_dir.parent
    MAX_DEPTH -= 1
    if MAX_DEPTH == 0:
        raise RecursionError(f"'{BASE_DIR}' not found in path: {__file__}")
parent_path = test_dir.parent.resolve()

sys.path.append(str(parent_path))    
    
from typing import Any, ClassVar, Dict, Type

from ibm_watsonx_orchestrate.agent_builder.tools import tool
from marshmallow import Schema
from marshmallow_dataclass import dataclass

from agent_ready_tools.clients.google_client import get_google_client
from agent_ready_tools.utils.tool_connections import GOOGLE_CONNECTIONS


@dataclass
class AddACommentResponse:
    """Represents the result of adding a comment to a file in Google Drive."""

    content: str
    Schema: ClassVar[Type[Schema]]


@tool(expected_credentials=GOOGLE_CONNECTIONS.as_json_list)
def add_a_comment_google_drive(file_id: str, content: str) -> AddACommentResponse:
    """
    Adds a comment to a specified file in Google Drive.

    :param file_id: Unique identifier for a file in Google Drive.
    :param content: The text of the comment.
    :return: The content of the added comment.
    """
    client = get_google_client()

    params: Dict[str, Any] = {
        "fields": "*",
    }
    payload: Dict[str, Any] = {"name": file_id, "content": content}

    response = client.post_request(
        entity=f"files/{file_id}/comments", payload=payload, params=params
    )

    return AddACommentResponse(content=response.get("content", ""))
